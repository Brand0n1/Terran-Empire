package HoodedBots.TerranEmpire;

public class Ref {
	
	public static final String TOKEN = "NDAyNTY2MDQ3MzA1MTcwOTgx.DT6mYA.ZXPyDb4cPVLkscPz7tqhrmU9dds";
	public static final String CLIENT_ID= "402566047305170981";
	public static final String PREFIX = "/";

}

